"""Pydantic schemas for API"""
